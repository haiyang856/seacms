<?php
/**
 * 海洋CMS API接口 - json.php
 * 用于提供完整的JSON数据接口给APP调用
 */

// 错误报告设置
error_reporting(0);
header('Content-Type: application/json; charset=utf-8');

// 引入公共文件
require_once('include/common.php');

// ==================== API全局配置 ====================
// API开关：true=开启，false=关闭
define('API_ENABLED', false);

// API关闭时的提示信息
define('API_DISABLED_MSG', 'API服务已关闭，请联系管理员');

// API白名单：只允许这些接口在API关闭时访问（可选，留空表示全部关闭）
$API_WHITELIST = [];

// 获取请求参数
$ac = isset($_GET['ac']) ? trim($_GET['ac']) : 'siteinfo';
$callback = isset($_GET['callback']) ? trim($_GET['callback']) : '';

// ==================== API开关检查 ====================
if (!API_ENABLED) {
    // 检查是否在白名单中
    $in_whitelist = !empty($API_WHITELIST) && in_array($ac, $API_WHITELIST);
    if (!$in_whitelist) {
        json_output([
            'api_status' => 'disabled',
            'timestamp' => time()
        ], 503, API_DISABLED_MSG);
    }
}

// 定义API返回函数
function json_output($data, $code = 200, $msg = 'success') {
    global $callback;
    $result = [
        'code' => $code,
        'msg' => $msg,
        'data' => $data,
        'time' => time()
    ];
    if ($callback) {
        echo $callback . '(' . json_encode($result, JSON_UNESCAPED_UNICODE) . ')';
    } else {
        echo json_encode($result, JSON_UNESCAPED_UNICODE);
    }
    exit;
}

// 获取网站配置信息
function get_site_config() {
    global $dsql;
    $config = [];
    
    // 从配置文件读取基础信息
    $config['site_name'] = $GLOBALS['cfg_webname'];
    $config['site_url'] = $GLOBALS['cfg_basehost'];
    $config['site_keywords'] = $GLOBALS['cfg_keywords'];
    $config['site_description'] = $GLOBALS['cfg_description'];
    $config['site_icp'] = $GLOBALS['cfg_beian'];
    $config['site_copyright'] = $GLOBALS['cfg_powerby'];
    $config['site_version'] = $GLOBALS['cfg_version'];
    
    // 获取统计数据
    $total_video = $dsql->GetOne("SELECT COUNT(*) as count FROM sea_data WHERE v_recycled=0");
    $total_news = $dsql->GetOne("SELECT COUNT(*) as count FROM sea_news WHERE n_recycled=0");
    $total_member = $dsql->GetOne("SELECT COUNT(*) as count FROM sea_member");
    $total_comment = $dsql->GetOne("SELECT COUNT(*) as count FROM sea_comment WHERE ischeck=1");
    
    $config['total_video'] = $total_video['count'];
    $config['total_news'] = $total_news['count'];
    $config['total_member'] = $total_member['count'];
    $config['total_comment'] = $total_comment['count'];
    
    return $config;
}

// 获取视频分类列表
function get_video_types($upid = 0) {
    global $dsql;
    $types = [];
    $dsql->SetQuery("SELECT * FROM sea_type WHERE tptype=0 AND upid='$upid' AND ishidden=0 ORDER BY torder ASC");
    $dsql->Execute('types');
    while($row = $dsql->GetArray('types')) {
        $type = [
            'id' => $row['tid'],
            'name' => $row['tname'],
            'upid' => $row['upid'],
            'order' => $row['torder']
        ];
        // 递归获取子分类
        $type['children'] = get_video_types($row['tid']);
        $types[] = $type;
    }
    return $types;
}

// 获取文章分类列表
function get_news_types($upid = 0) {
    global $dsql;
    $types = [];
    $dsql->SetQuery("SELECT * FROM sea_type WHERE tptype=1 AND upid='$upid' AND ishidden=0 ORDER BY torder ASC");
    $dsql->Execute('types');
    while($row = $dsql->GetArray('types')) {
        $type = [
            'id' => $row['tid'],
            'name' => $row['tname'],
            'upid' => $row['upid'],
            'order' => $row['torder']
        ];
        $type['children'] = get_news_types($row['tid']);
        $types[] = $type;
    }
    return $types;
}

// 获取视频列表
function get_video_list($params = []) {
    global $dsql;
    $page = isset($params['page']) ? max(1, intval($params['page'])) : 1;
    $pagesize = isset($params['pagesize']) ? max(1, intval($params['pagesize'])) : 20;
    $type = isset($params['type']) ? intval($params['type']) : 0;
    $order = isset($params['order']) ? trim($params['order']) : 'time';
    $keyword = isset($params['keyword']) ? trim($params['keyword']) : '';
    $state = isset($params['state']) ? intval($params['state']) : -1;
    $area = isset($params['area']) ? trim($params['area']) : '';
    $year = isset($params['year']) ? trim($params['year']) : '';
    $letter = isset($params['letter']) ? trim($params['letter']) : '';
    $lang = isset($params['lang']) ? trim($params['lang']) : '';
    $commend = isset($params['commend']) ? intval($params['commend']) : -1;
    
    $offset = ($page - 1) * $pagesize;
    $where = ['v_recycled=0'];
    
    if ($type > 0) {
        $where[] = "tid='$type'";
    }
    if ($keyword) {
        $where[] = "(v_name LIKE '%$keyword%' OR v_actor LIKE '%$keyword%' OR v_director LIKE '%$keyword%' OR v_nickname LIKE '%$keyword%')";
    }
    if ($state >= 0) {
        $where[] = "v_state='$state'";
    }
    if ($area) {
        $where[] = "v_publisharea='$area'";
    }
    if ($year) {
        $where[] = "v_publishyear='$year'";
    }
    if ($letter) {
        $where[] = "v_letter='$letter'";
    }
    if ($lang) {
        $where[] = "v_lang='$lang'";
    }
    if ($commend >= 0) {
        $where[] = "v_commend='$commend'";
    }
    
    $where_str = implode(' AND ', $where);
    
    // 排序
    $order_map = [
        'time' => 'v_addtime DESC',
        'timeasc' => 'v_addtime ASC',
        'hit' => 'v_hit DESC',
        'hitasc' => 'v_hit ASC',
        'score' => 'v_score DESC',
        'id' => 'v_id DESC',
        'idasc' => 'v_id ASC',
        'commend' => 'v_commend DESC',
        'random' => 'RAND()'
    ];
    $order_str = isset($order_map[$order]) ? $order_map[$order] : $order_map['time'];
    
    // 获取总数
    $count_sql = "SELECT COUNT(*) as total FROM sea_data WHERE $where_str";
    $count = $dsql->GetOne($count_sql);
    $total = $count['total'];
    
    // 获取数据
    $list = [];
    $sql = "SELECT v_id,tid,v_name,v_nickname,v_actor,v_director,v_pic,v_spic,v_state,v_hit,v_digg,v_tread,v_score,v_scorenum,v_commend,v_addtime,v_publishyear,v_publisharea,v_lang,v_note,v_letter,v_money FROM sea_data WHERE $where_str ORDER BY $order_str LIMIT $offset,$pagesize";
    $dsql->SetQuery($sql);
    $dsql->Execute('videos');
    while($row = $dsql->GetArray('videos')) {
        $video = [
            'id' => $row['v_id'],
            'type_id' => $row['tid'],
            'name' => $row['v_name'],
            'nickname' => $row['v_nickname'],
            'actor' => $row['v_actor'],
            'director' => $row['v_director'],
            'pic' => $row['v_pic'],
            'spic' => $row['v_spic'],
            'state' => $row['v_state'],
            'hit' => $row['v_hit'],
            'digg' => $row['v_digg'],
            'tread' => $row['v_tread'],
            'score' => $row['v_score'],
            'scorenum' => $row['v_scorenum'],
            'commend' => $row['v_commend'],
            'addtime' => $row['v_addtime'],
            'year' => $row['v_publishyear'],
            'area' => $row['v_publisharea'],
            'lang' => $row['v_lang'],
            'note' => $row['v_note'],
            'letter' => $row['v_letter'],
            'money' => $row['v_money']
        ];
        $list[] = $video;
    }
    
    return [
        'list' => $list,
        'total' => $total,
        'page' => $page,
        'pagesize' => $pagesize,
        'totalpage' => ceil($total / $pagesize)
    ];
}

// 获取视频详情
function get_video_detail($id) {
    global $dsql;
    $id = intval($id);
    
    // 基本信息
    $video = $dsql->GetOne("SELECT * FROM sea_data WHERE v_id='$id'");
    if (!$video) {
        return null;
    }
    
    // 详细内容
    $content = $dsql->GetOne("SELECT body FROM sea_content WHERE v_id='$id'");
    $video['body'] = $content ? $content['body'] : '';
    
    // 播放地址
    $playdata = $dsql->GetOne("SELECT * FROM sea_playdata WHERE v_id='$id'");
    $video['playdata'] = $playdata ? $playdata['body'] : '';
    $video['downloaddata'] = $playdata ? $playdata['body1'] : '';
    
    // 分类名称
    $type = $dsql->GetOne("SELECT tname FROM sea_type WHERE tid='{$video['tid']}'");
    $video['typename'] = $type ? $type['tname'] : '';
    
    return $video;
}

// 获取文章列表
function get_news_list($params = []) {
    global $dsql;
    $page = isset($params['page']) ? max(1, intval($params['page'])) : 1;
    $pagesize = isset($params['pagesize']) ? max(1, intval($params['pagesize'])) : 20;
    $type = isset($params['type']) ? intval($params['type']) : 0;
    $keyword = isset($params['keyword']) ? trim($params['keyword']) : '';
    
    $offset = ($page - 1) * $pagesize;
    $where = ['n_recycled=0'];
    
    if ($type > 0) {
        $where[] = "tid='$type'";
    }
    if ($keyword) {
        $where[] = "(n_title LIKE '%$keyword%' OR n_keyword LIKE '%$keyword%')";
    }
    
    $where_str = implode(' AND ', $where);
    
    // 获取总数
    $count = $dsql->GetOne("SELECT COUNT(*) as total FROM sea_news WHERE $where_str");
    $total = $count['total'];
    
    // 获取数据
    $list = [];
    $sql = "SELECT n_id,tid,n_title,n_pic,n_author,n_hit,n_digg,n_tread,n_addtime,n_outline,n_note FROM sea_news WHERE $where_str ORDER BY n_addtime DESC LIMIT $offset,$pagesize";
    $dsql->SetQuery($sql);
    $dsql->Execute('news');
    while($row = $dsql->GetArray('news')) {
        $news = [
            'id' => $row['n_id'],
            'type_id' => $row['tid'],
            'title' => $row['n_title'],
            'pic' => $row['n_pic'],
            'author' => $row['n_author'],
            'hit' => $row['n_hit'],
            'digg' => $row['n_digg'],
            'tread' => $row['n_tread'],
            'addtime' => $row['n_addtime'],
            'outline' => $row['n_outline'],
            'note' => $row['n_note']
        ];
        $list[] = $news;
    }
    
    return [
        'list' => $list,
        'total' => $total,
        'page' => $page,
        'pagesize' => $pagesize,
        'totalpage' => ceil($total / $pagesize)
    ];
}

// 获取文章详情
function get_news_detail($id) {
    global $dsql;
    $id = intval($id);
    $news = $dsql->GetOne("SELECT * FROM sea_news WHERE n_id='$id'");
    if (!$news) {
        return null;
    }
    // 分类名称
    $type = $dsql->GetOne("SELECT tname FROM sea_type WHERE tid='{$news['tid']}'");
    $news['typename'] = $type ? $type['tname'] : '';
    return $news;
}

// 获取评论列表
function get_comment_list($params = []) {
    global $dsql;
    $page = isset($params['page']) ? max(1, intval($params['page'])) : 1;
    $pagesize = isset($params['pagesize']) ? max(1, intval($params['pagesize'])) : 20;
    $vid = isset($params['vid']) ? intval($params['vid']) : 0;
    $typeid = isset($params['typeid']) ? intval($params['typeid']) : 0;
    
    $offset = ($page - 1) * $pagesize;
    $where = ['ischeck=1'];
    
    if ($vid > 0) {
        $where[] = "v_id='$vid'";
    }
    if ($typeid > 0) {
        $where[] = "typeid='$typeid'";
    }
    
    $where_str = implode(' AND ', $where);
    
    $count = $dsql->GetOne("SELECT COUNT(*) as total FROM sea_comment WHERE $where_str");
    $total = $count['total'];
    
    $list = [];
    $sql = "SELECT * FROM sea_comment WHERE $where_str ORDER BY dtime DESC LIMIT $offset,$pagesize";
    $dsql->SetQuery($sql);
    $dsql->Execute('comments');
    while($row = $dsql->GetArray('comments')) {
        $list[] = $row;
    }
    
    return [
        'list' => $list,
        'total' => $total,
        'page' => $page,
        'pagesize' => $pagesize,
        'totalpage' => ceil($total / $pagesize)
    ];
}

// 获取留言列表
function get_guestbook_list($params = []) {
    global $dsql;
    $page = isset($params['page']) ? max(1, intval($params['page'])) : 1;
    $pagesize = isset($params['pagesize']) ? max(1, intval($params['pagesize'])) : 20;
    
    $offset = ($page - 1) * $pagesize;
    
    $count = $dsql->GetOne("SELECT COUNT(*) as total FROM sea_guestbook WHERE ischeck=1");
    $total = $count['total'];
    
    $list = [];
    $sql = "SELECT * FROM sea_guestbook WHERE ischeck=1 ORDER BY dtime DESC LIMIT $offset,$pagesize";
    $dsql->SetQuery($sql);
    $dsql->Execute('guestbook');
    while($row = $dsql->GetArray('guestbook')) {
        $list[] = $row;
    }
    
    return [
        'list' => $list,
        'total' => $total,
        'page' => $page,
        'pagesize' => $pagesize,
        'totalpage' => ceil($total / $pagesize)
    ];
}

// 获取会员收藏列表
function get_favorite_list($uid, $params = []) {
    global $dsql;
    $uid = intval($uid);
    $page = isset($params['page']) ? max(1, intval($params['page'])) : 1;
    $pagesize = isset($params['pagesize']) ? max(1, intval($params['pagesize'])) : 20;
    
    $offset = ($page - 1) * $pagesize;
    
    $count = $dsql->GetOne("SELECT COUNT(*) as total FROM sea_favorite WHERE uid='$uid'");
    $total = $count['total'];
    
    $list = [];
    $sql = "SELECT f.*,d.v_name,d.v_pic FROM sea_favorite f LEFT JOIN sea_data d ON f.vid=d.v_id WHERE f.uid='$uid' ORDER BY f.kptime DESC LIMIT $offset,$pagesize";
    $dsql->SetQuery($sql);
    $dsql->Execute('favorites');
    while($row = $dsql->GetArray('favorites')) {
        $list[] = $row;
    }
    
    return [
        'list' => $list,
        'total' => $total,
        'page' => $page,
        'pagesize' => $pagesize,
        'totalpage' => ceil($total / $pagesize)
    ];
}

// 获取会员信息
function get_member_info($uid) {
    global $dsql;
    $uid = intval($uid);
    $member = $dsql->GetOne("SELECT * FROM sea_member WHERE id='$uid'");
    if ($member) {
        unset($member['password']);
        return $member;
    }
    return null;
}

// 获取专题列表
function get_topic_list($params = []) {
    global $dsql;
    $page = isset($params['page']) ? max(1, intval($params['page'])) : 1;
    $pagesize = isset($params['pagesize']) ? max(1, intval($params['pagesize'])) : 20;
    
    $offset = ($page - 1) * $pagesize;
    
    $count = $dsql->GetOne("SELECT COUNT(*) as total FROM sea_topic");
    $total = $count['total'];
    
    $list = [];
    $sql = "SELECT * FROM sea_topic ORDER BY addtime DESC LIMIT $offset,$pagesize";
    $dsql->SetQuery($sql);
    $dsql->Execute('topics');
    while($row = $dsql->GetArray('topics')) {
        $list[] = $row;
    }
    
    return [
        'list' => $list,
        'total' => $total,
        'page' => $page,
        'pagesize' => $pagesize,
        'totalpage' => ceil($total / $pagesize)
    ];
}

// 获取友情链接
function get_link_list($type = '') {
    global $dsql;
    $list = [];
    $where = 'ischeck=1';
    if ($type) {
        $where .= " AND logo='$type'";
    }
    $sql = "SELECT * FROM sea_flink WHERE $where ORDER BY sortrank ASC";
    $dsql->SetQuery($sql);
    $dsql->Execute('links');
    while($row = $dsql->GetArray('links')) {
        $list[] = $row;
    }
    return $list;
}

// 获取搜索热词
function get_hot_keywords($limit = 20) {
    global $dsql;
    $list = [];
    $sql = "SELECT keyword,count FROM sea_search_keywords ORDER BY count DESC LIMIT $limit";
    $dsql->SetQuery($sql);
    $dsql->Execute('keywords');
    while($row = $dsql->GetArray('keywords')) {
        $list[] = $row;
    }
    return $list;
}

// 获取筛选选项
function get_filter_options() {
    global $dsql;
    $options = [];
    
    // 年份
    $years = [];
    $dsql->SetQuery("SELECT DISTINCT v_publishyear FROM sea_data WHERE v_publishyear!='' AND v_recycled=0 ORDER BY v_publishyear DESC");
    $dsql->Execute('years');
    while($row = $dsql->GetArray('years')) {
        if ($row['v_publishyear']) {
            $years[] = $row['v_publishyear'];
        }
    }
    $options['years'] = $years;
    
    // 地区
    $areas = [];
    $dsql->SetQuery("SELECT DISTINCT v_publisharea FROM sea_data WHERE v_publisharea!='' AND v_recycled=0 ORDER BY v_publisharea ASC");
    $dsql->Execute('areas');
    while($row = $dsql->GetArray('areas')) {
        if ($row['v_publisharea']) {
            $areas[] = $row['v_publisharea'];
        }
    }
    $options['areas'] = $areas;
    
    // 语言
    $langs = [];
    $dsql->SetQuery("SELECT DISTINCT v_lang FROM sea_data WHERE v_lang!='' AND v_recycled=0 ORDER BY v_lang ASC");
    $dsql->Execute('langs');
    while($row = $dsql->GetArray('langs')) {
        if ($row['v_lang']) {
            $langs[] = $row['v_lang'];
        }
    }
    $options['langs'] = $langs;
    
    // 首字母
    $letters = [];
    $dsql->SetQuery("SELECT DISTINCT v_letter FROM sea_data WHERE v_letter!='' AND v_recycled=0 ORDER BY v_letter ASC");
    $dsql->Execute('letters');
    while($row = $dsql->GetArray('letters')) {
        if ($row['v_letter']) {
            $letters[] = $row['v_letter'];
        }
    }
    $options['letters'] = $letters;
    
    return $options;
}

// API路由处理
switch($ac) {
    // 网站信息
    case 'siteinfo':
        $data = [
            'site' => get_site_config(),
            'video_types' => get_video_types(),
            'news_types' => get_news_types(),
            'hot_keywords' => get_hot_keywords(10),
            'filter_options' => get_filter_options()
        ];
        json_output($data);
        break;
    
    // 视频相关
    case 'videolist':
        $data = get_video_list($_GET);
        json_output($data);
        break;
    
    case 'videodetail':
        $id = isset($_GET['id']) ? intval($_GET['id']) : 0;
        if (!$id) {
            json_output(null, 400, '参数错误');
        }
        $data = get_video_detail($id);
        if ($data) {
            json_output($data);
        } else {
            json_output(null, 404, '视频不存在');
        }
        break;
    
    case 'videotypes':
        $data = get_video_types();
        json_output($data);
        break;
    
    // 文章相关
    case 'newslist':
        $data = get_news_list($_GET);
        json_output($data);
        break;
    
    case 'newsdetail':
        $id = isset($_GET['id']) ? intval($_GET['id']) : 0;
        if (!$id) {
            json_output(null, 400, '参数错误');
        }
        $data = get_news_detail($id);
        if ($data) {
            json_output($data);
        } else {
            json_output(null, 404, '文章不存在');
        }
        break;
    
    case 'newstypes':
        $data = get_news_types();
        json_output($data);
        break;
    
    // 评论相关
    case 'commentlist':
        $data = get_comment_list($_GET);
        json_output($data);
        break;
    
    // 留言相关
    case 'guestbooklist':
        $data = get_guestbook_list($_GET);
        json_output($data);
        break;
    
    // 会员相关
    case 'memberinfo':
        $uid = isset($_GET['uid']) ? intval($_GET['uid']) : 0;
        if (!$uid) {
            json_output(null, 400, '参数错误');
        }
        $data = get_member_info($uid);
        if ($data) {
            json_output($data);
        } else {
            json_output(null, 404, '会员不存在');
        }
        break;
    
    case 'favoritelist':
        $uid = isset($_GET['uid']) ? intval($_GET['uid']) : 0;
        if (!$uid) {
            json_output(null, 400, '参数错误');
        }
        $data = get_favorite_list($uid, $_GET);
        json_output($data);
        break;
    
    // 专题相关
    case 'topiclist':
        $data = get_topic_list($_GET);
        json_output($data);
        break;
    
    // 友情链接
    case 'linklist':
        $type = isset($_GET['type']) ? trim($_GET['type']) : '';
        $data = get_link_list($type);
        json_output($data);
        break;
    
    // 搜索热词
    case 'hotkeywords':
        $limit = isset($_GET['limit']) ? intval($_GET['limit']) : 20;
        $data = get_hot_keywords($limit);
        json_output($data);
        break;
    
    // 筛选选项
    case 'filteroptions':
        $data = get_filter_options();
        json_output($data);
        break;
    
    // 首页数据聚合
    case 'home':
        $data = [
            'site' => get_site_config(),
            'hot_videos' => get_video_list(['order' => 'hit', 'pagesize' => 10]),
            'new_videos' => get_video_list(['order' => 'time', 'pagesize' => 10]),
            'recommend_videos' => get_video_list(['commend' => 1, 'pagesize' => 10]),
            'news' => get_news_list(['pagesize' => 10]),
            'hot_keywords' => get_hot_keywords(10)
        ];
        json_output($data);
        break;
    
    default:
        json_output([
            'doc' => '海洋CMS API接口文档',
            'version' => '1.1.0',
            'api_enabled' => API_ENABLED,
            'endpoints' => [
                'siteinfo' => '获取网站基本信息',
                'home' => '获取首页聚合数据',
                'videolist' => '获取视频列表',
                'videodetail' => '获取视频详情',
                'videotypes' => '获取视频分类',
                'newslist' => '获取文章列表',
                'newsdetail' => '获取文章详情',
                'newstypes' => '获取文章分类',
                'commentlist' => '获取评论列表',
                'guestbooklist' => '获取留言列表',
                'memberinfo' => '获取会员信息',
                'favoritelist' => '获取收藏列表',
                'topiclist' => '获取专题列表',
                'linklist' => '获取友情链接',
                'hotkeywords' => '获取热门搜索词',
                'filteroptions' => '获取筛选选项'
            ]
        ]);
        break;
}
?>